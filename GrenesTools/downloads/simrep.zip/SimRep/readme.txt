Auto install:
Edit Simple Reporter.xml 
Change store id and pos num in <Arguments>
after server IP.

Manual install:

Copy to c:\Program Files\SimRep\
Setup scheduled task.
General:
change user account: System
Run whether user is logged on or not.
Hidden yes

Triggers:
Daily
Repeat task every: 5 minutes - repeat indefinetly
Enable

Actions:
Start a program
Path: "C:\Program Files\SimRep\SimpleRepoter.exe"
#Add arguments: [host]/pos_api.php [store_id] [pos_num]
#http://192.168.100.11/pos_api.php 1020 1

Conditions: change nothing

Settings:
Run on demand - yes
Runs as soon as possible - yes
Stop if runs more than 1 hour - yes
Force stop - yes
"Do not start new instance"
